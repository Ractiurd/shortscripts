document.querySelectorAll(".tab").forEach(function(tab, index) {
    tab.addEventListener("click", function() {
        var fileName = "";
        switch (index) {
            case 0:
                fileName = "Xss.txt";
                break;
            case 1:
                fileName = "Sqli.txt";
                break;
            case 2:
                fileName = "htmli.txt";
                break;
            case 3:
                fileName = "blind.txt";
                break;
            case 4:
                fileName = "header.txt";
                break;
        }

        fetch(fileName)
            .then(response => response.text())
            .then(data => {
                // Split content by lines
                var lines = data.split("\n");

                // Clear previous content
                document.getElementById("content").innerHTML = "";

                // Display each line in a box
                lines.forEach(function(line) {
                    var box = document.createElement("div");
                    box.className = "line-box";
                    box.textContent = line;

                    // Add copy button
                    var copyButton = document.createElement("button");
                    copyButton.className = "copy-button";
                    copyButton.textContent = "Copy";
                    copyButton.onclick = function() {
                        var originalBackgroundColor = box.style.backgroundColor;
                        var originalButtonDisplay = copyButton.style.display;
                        // Change background color to gray
                        box.style.backgroundColor = "#ccc";
                        copyButton.style.display = "none";
                        setTimeout(function() {
                            // Revert background color and button display after 2 seconds
                            box.style.backgroundColor = originalBackgroundColor;
                            copyButton.style.display = originalButtonDisplay;
                        }, 2000);
                        navigator.clipboard.writeText(line)
                            .catch(err => {
                                console.error('Error copying text: ', err);
                            });
                    };
                    box.appendChild(copyButton);

                    document.getElementById("content").appendChild(box);
                });
            })
            .catch(error => {
                console.error('Error fetching file:', error);
            });
    });
});
