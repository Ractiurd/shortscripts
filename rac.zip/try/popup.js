// popup.js
document.addEventListener('DOMContentLoaded', function () {
  const textContainer = document.getElementById('textContainer');
  const addButton = document.getElementById('addButton');
  let textBoxCounter = 1; // Counter for text boxes

  // Load saved text when the extension is opened
  chrome.storage.sync.get(['texts'], function (result) {
    if (result.texts) {
      result.texts.forEach(function (text) {
        const textBox = createTextBox(text, textBoxCounter++);
        textContainer.appendChild(textBox);
      });
    }
  });

  addButton.addEventListener('click', function () {
    const textBox = createTextBox('', textBoxCounter++);
    textContainer.appendChild(textBox);
    enableTextBox(textBox); // Allow writing immediately after adding
  });

  function createTextBox(savedText, textBoxNumber) {
    const textBox = document.createElement('div');
    textBox.classList.add('text-box');

    const numberLabel = document.createElement('span');
    numberLabel.textContent = textBoxNumber + '.';
    textBox.appendChild(numberLabel);

    const textarea = document.createElement('textarea');
    textarea.rows = 1; // Reduced size
    textarea.cols = 20; // Reduced size
    textarea.value = savedText || ''; // Set saved text if available
    textarea.readOnly = true; // Set textarea to read-only initially
    textBox.appendChild(textarea);

    const actionButton = document.createElement('button');
    actionButton.textContent = savedText ? 'Edit' : 'Save'; // Initially set to 'Save' or 'Edit' based on saved text
    actionButton.addEventListener('click', function () {
      if (actionButton.textContent === 'Save') {
        saveText(textarea, actionButton);
      } else {
        editText(textarea, actionButton);
      }
    });
    textBox.appendChild(actionButton);

    const copyButton = document.createElement('button');
    copyButton.textContent = 'Copy';
    copyButton.addEventListener('click', function () {
      copyText(textarea.value);
    });
    textBox.appendChild(copyButton);

    const deleteButton = document.createElement('button');
    deleteButton.textContent = 'Delete';
    deleteButton.addEventListener('click', function () {
      textContainer.removeChild(textBox);
      removeTextFromStorage(textarea.value);
    });
    textBox.appendChild(deleteButton);

    return textBox;
  }

  function saveText(textarea, actionButton) {
    const newText = textarea.value;
    chrome.storage.sync.get(['texts'], function (result) {
      const texts = result.texts || [];
      if (!texts.includes(newText)) {
        texts.push(newText);
        chrome.storage.sync.set({ 'texts': texts });
      }
    });
    actionButton.textContent = 'Edit';
    textarea.readOnly = true; // Set textarea back to read-only
  }

  function editText(textarea, actionButton) {
    textarea.readOnly = false; // Make textarea editable
    textarea.focus(); // Focus on textarea
    actionButton.textContent = 'Save'; // Change button text to 'Save'
  }

  function enableTextBox(textBox) {
    const textarea = textBox.querySelector('textarea');
    textarea.readOnly = false; // Allow writing immediately after adding
    textarea.focus(); // Focus on the new textarea
  }

  function removeTextFromStorage(text) {
    chrome.storage.sync.get(['texts'], function (result) {
      const texts = result.texts || [];
      const index = texts.indexOf(text);
      if (index !== -1) {
        texts.splice(index, 1);
        chrome.storage.sync.set({ 'texts': texts });
      }
    });
  }

  function copyText(text) {
    navigator.clipboard.writeText(text.trim());
  }
});
